const popper = require('@popperjs/core');
const bootstrap = require('./bootstrap');
const tinymce = require('tinymce');
require('tinymce/themes/silver');
require('tinymce/icons/default');