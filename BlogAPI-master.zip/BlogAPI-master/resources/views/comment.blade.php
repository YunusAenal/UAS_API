@extends('layouts.app')

@section('content')
    <div class="container">
        <h1 class="text-center">Comment</h1>
    </div>
@endsection