@extends('layouts.app')

@section('title', 'View Articles')

@section('content')
    <h2 class="m-5 p-0">{{ $data->title }}</h2>
    <p class="content p-2">{!! $data->content !!}</p>

    <div class="dropdown-divider"></div>

    <form method="post" action="{{ route('new_comment') }}">
        @csrf

        {{-- <a href="{{ route('see_comment') }}" class="btn btn-info text-center text-white">See Comment</a> --}}
        <a href="#" class="btn btn-info text-center text-white">See Comment</a>

        <h3 class="text-center">Comment</h3>

        <div class="mb-3">
            <div class="col-md-4">
                <input type="hidden" class="form-control" id="frm-article-id" name="frm-article-id" value="{{ $data->id }}" readonly>
            </div>
        </div>
        <div class="mb-3">
            <div class="col-md-4">
                <label for="frm-author" class="form-label"><small>Author</small></label>
                <input type="text" class="form-control" id="frm-author" name="frm-author" value="{{ session()->get('name') }}" readonly>
            </div>
        </div>
        <div class="mb-3">
            <label for="frm-comment" class="form-label"><small>Comment</small></label>
            <textarea class="form-control" id="frm-comment" name="frm-comment" placeholder="Type text in here..." rows="3"></textarea>
        </div>
        <div class="mb-3">
            <button type="submit" class="btn btn-info form-control text-white">Comment</button>
        </div>
    </form>
@endsection